#include "add.h"
#include <stdio.h>

int main() {
	int x = 10, y = 20;
	printf("\n%d + %d = %d\n", x, y, add(x, y));
	return 0;
}


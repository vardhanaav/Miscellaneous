int add(int q1, int q2) {
	return (q1 + q2);
}

#echo 'creating shared lib'
#gcc -o addDemo addDemo.c libheymath.so
#echo 'created successfully'
echo '-----showing add.h-----'
cat add.h
echo ' '
echo '-----showing addDemo.c-----'
cat addDemo.c
echo ' '
echo '-----showing add.c-----'
cat add.c
echo ' '
echo '-----creating shared lib libheymath.so-----'
#gcc -Wall -fPIC -c add.c
gcc -shared -o libheymath.so add.o
#sudo cp -a libheymath.so /usr/lib/libheymath.so
#cd /usr/lib
#sudo ldconfig libheymath.so
#cd ~
echo '-----lib created successfully. It is installed in /usr/lib using ldconfig-----'
gcc -c addDemo.c
echo ' '
echo '-----compiling without libheymath.so-----'
gcc -o addDemo addDemo.c
echo ' '
echo '-----compiling with libheymath.so-----'
gcc -o addDemo addDemo.c libheymath.so
./addDemo



